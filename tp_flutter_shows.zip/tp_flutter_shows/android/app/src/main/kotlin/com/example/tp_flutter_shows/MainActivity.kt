package com.example.tp_flutter_shows

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
